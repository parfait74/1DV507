package fs222mh_assign2.ex5;

public class IntValue {
	public int value;
	
	public IntValue(int i) {
		value = i;
	}

}
