package fs222mh_assign2.ex5;

public class UpDownMain {
public static void main(String[] args) {
		
		new UpDownPane().fire();

	}

}
