package fs222mh_assign2.ex6;


public class CatchTheCreatureMain {
	public static void main(String[] args) {
		
		new CatchTheCreature().fire();

	}

}
