package fs222mh_assign2.ex7;

public class HistogramMain {

	public static void main(String[] args) {
		
		new HistogramGui().fire();

	}

}
